package apitestcases;

import org.testng.annotations.Test;
import org.json.simple.JSONObject;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import io.restassured.http.ContentType;

public class AssignmentEightApi {
	
	@Test(priority = 1)
	public void testGetRequestSingleUserNotFound() {
		System.out.println("-----Testcase 1-----");
		
		baseURI = "https://reqres.in/api";
		given()
			.get("/users/23")
		.then()
			.statusCode(404)
			.log().all();
	}
	
	@Test(priority = 2)
	public void testGetRequestListResource() {
		System.out.println("-----Testcase 2-----");
		
		baseURI = "https://reqres.in/api";
		given()
			.get("/unknown")
		.then()
			.statusCode(200)
			.body("data[0].name", equalTo("cerulean"))
			.body("data[0].year", equalTo(2000))
			.body("data.name", hasItems("fuchsia rose", "true red", "aqua sky"))
			.body("page", equalTo(1))
			.body("per_page", equalTo(6))
			.body("total", equalTo(12))
			.body("total_pages", equalTo(2))
			.log().headers()
			.log().status()
			.log().body();
	}

	@Test(priority = 3)
	public void testGetRequestSingleResourceNotFound() {
		System.out.println("-----Testcase 3-----");
		
		baseURI = "https://reqres.in/api";
		given()
			.get("/unknown/23")
		.then()
			.statusCode(404)
			.log().all();
	}
	
	@Test(priority = 4)
	public void testGetRequestSingleResource() {
		System.out.println("-----Testcase 4-----");
		
		baseURI = "https://reqres.in/api";
		given()
			.get("/unknown/2")
		.then()
			.statusCode(200)
			.body("data.id", equalTo(2))
			.body("data.name", equalTo("fuchsia rose"))
			.body("data.year", equalTo(2001))
			.body("data.color", equalTo("#C74375"))
			.body("data.pantone_value", equalTo("17-2031"))
			.log().headers()
			.log().status()
			.log().body();
	}
	
	@Test(priority = 5)
	public void testPostRequestRegisterSuccessful() {
		System.out.println("-----Testcase 5-----");
		
		baseURI = "https://reqres.in/api";
		JSONObject jsondata = new JSONObject();
		
		jsondata.put("email", "eve.holt@reqres.in");
		jsondata.put("password", "pistol");
		System.out.println(jsondata.toJSONString());

		given()
			.body(jsondata.toJSONString())
			.header("Connection", "Keep-alive")
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
		.when()
			.post("/register")
		.then()
			.statusCode(200)
			.log().ifStatusCodeIsEqualTo(200)
			.log().body();
	}
	
	@Test(priority = 6)
	public void testPostRequestRegisterUnsuccessful() {
		System.out.println("-----Testcase 6-----");
		
		baseURI = "https://reqres.in/api";
		JSONObject jsondata1 = new JSONObject();
		
		jsondata1.put("email", "sydney@fife");
		System.out.println(jsondata1.toJSONString());

		given()
			.body(jsondata1.toJSONString())
			.header("Connection", "Keep-alive")
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
		.when()
			.post("/register")
		.then()
			.statusCode(400)
			.body("error", equalTo("Missing password"))
			.log().body();
	}

	@Test(priority = 7)
	public void testPostRequestLoginUnsuccessful() {
		System.out.println("-----Testcase 7-----");

		baseURI = "https://reqres.in/api";
		JSONObject jsondata2 = new JSONObject();
		
		jsondata2.put("email", "peter@klaven");
		System.out.println(jsondata2.toJSONString());

		given()
			.body(jsondata2.toJSONString())
			.header("Connection", "Keep-alive")
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
		.when()
			.post("/login")
		.then()
			.statusCode(400)
			.body("error", equalTo("Missing password"))
			.log().body();
	}

}