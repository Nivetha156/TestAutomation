package apitestcases;

import static io.restassured.RestAssured.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class ApiExtractValueResponse {

	//Log in with the above created user >> extract token

	@Test
	public void testPostRequestRegisterUnsuccessful() {
		baseURI = "https://reqres.in/api";
		
		JSONObject json = new JSONObject();
		json.put("email", "eve.holt@reqres.in");
		json.put("password", "cityslicka");
		System.out.println(json.toJSONString());

		String tokenOne = 
			given()
				.body(json.toJSONString())
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.header("charset", "utf-8")
			.when()
				.post("/register")
			.then()
				.extract().path("token");

		//validated token
		System.out.println("Register token: " + tokenOne);

		int id = 
			given()
				.body(json.toJSONString())
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.header("charset", "utf-8")
			.when()
				.post("/register")
			.then()
				.extract().path("id");

		//validated id
		System.out.println("Register id: " + id);

		String tokenTwo =	
			given()
				.body(json.toJSONString())
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.header("charset", "utf-8")
			.when()
				.post("/login")
			.then()
				.extract().path("token")	;	

		System.out.println("Login token: " + tokenTwo);

		//run get single user to find the same user id >> validate name and job details

			given()
				.get("/users/"+id)
			.then()
				.body("data.first_name", equalTo("Eve"))
				.body("data.last_name", equalTo("Holt"))
				.body("data.email", equalTo("eve.holt@reqres.in"))
				.statusCode(200);
			System.out.println("------Validated Single User------");
		
		//SINGLE <RESOURCE> use the same user if >> validate details
		
			given()
				.get("/unknown/"+id)
			.then()
				.body("data.color", equalTo("#7BC4C4"))
				.body("data.name", equalTo("aqua sky"))
				.body("data.id", equalTo(4))
				.body("data.year",equalTo(2003))
				.statusCode(200);
			System.out.println("------Validated Single Resource------");

		//update user details  >> add validations >> search user and validate again

		json.put("name", "Michael");
		json.put("job", "SDET");

		try {
			given()
				.body(json.toJSONString())
			.when()
				.put("/users/"+id)
			.then()
				.body("name", equalTo("Michael"))
				.body("job", equalTo("SDET"))
				.log().body();
		} catch (AssertionError e) {
			e.printStackTrace();
		}
		
		System.out.println("------Updated user details------");

		//patch same user >> validate response >> search user >> validate
		
		json.put("name", "Patrick");
		json.put("job", "Devops");

		try {
			given()
				.body(json.toJSONString())
				.patch("/users/"+id)
			.then()
				.body("name", equalTo("Patrick"))
				.body("job", equalTo("Devops"))
				.log().body();
		} catch (AssertionError e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		System.out.println("------Patch update is over------");

		//delete same user >> validate code >> search user >> validate

		when()
			.delete("/users/"+id)
		.then()
			.statusCode(204)
			.log().body();

		System.out.println("------Deleted the user------");
	}
}


