package javabasics;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int age = 30;
		System.out.println("Age is " + age);

		age = 50;
		System.out.println("My age after 20yrs will be " +age);
		
		int hisAge = age;
		System.out.println("His age " + hisAge);
		
		byte herAge = 22;
		System.out.println("Her age " + herAge);
		
		long viewsCount = 3_123_456L;
		System.out.println("Count is " + viewsCount);
		
		float price = 10.99F;
		System.out.println("Float value is " + price);
		
		char letter = 'A';
		System.out.println("Char value is " + letter);
		
		boolean isEligible = true;
		System.out.println("Boolean value is " + isEligible);
		
	
	
	}
	

}
