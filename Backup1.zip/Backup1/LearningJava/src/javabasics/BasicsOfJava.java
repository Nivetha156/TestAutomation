package javabasics;

import java.util.Scanner;

public class BasicsOfJava {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Nivetha");
		
		Scanner input=new Scanner(System.in);
		System.out.println("What's your good name");
		String name = input.next();
		System.out.println("HI "+name);
		
		System.out.println("\nNive\nnivetha\t\tnivi\" s");
		
		
		
		
	}
	

}
