package restassuredtestcases;

import org.testng.annotations.Test;

import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;


public class ApiTestCases {

	@Test	
	public void createUserList()
	{	
		baseURI = "https://gorest.co.in/";

		given()
		.get("/public/v1/users2")
		.then()
		.log().status()
		.log().all();	
	}

	@Test
	public void getCreatedUserList()
	{
		baseURI = "https://gorest.co.in/";

		given()
		.get("/public/v1/users/100")
		.then()
		.log().status()
		.log().everything()
		.log().ifStatusCodeIsEqualTo(203)
		.log().ifValidationFails(LogDetail.STATUS)
		.log().all();
	}

	@Test
	public void updateCreateUser() {
		baseURI = "https://gorest.co.in/";

		JSONObject reqData = new JSONObject();

		reqData.put("name","John");
		reqData.put("job","Analyst");

		System.out.println(reqData.toJSONString());

		given()
		.header("content-type" , "application/json")
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData.toJSONString())
		.when()
		.put("/public/v1/users/100")
		.then()
		.log().status()
		.log().all();
	}
	
	@Test
	void findCreateUserInList()
	{

		baseURI = "https://gorest.co.in/";

		JSONObject reqData1 = new JSONObject();

		reqData1.put("name","John");
		reqData1.put("job","Teacher");

		System.out.println(reqData1.toJSONString());

		given()
		//	.header("content-type" , "application/json")
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData1.toJSONString())
		.when()
		.post("/public/v1/users/100/posts")
		.then()
		.log().status();
	}


	@Test
	public void testPostCreateUser() {
		baseURI = "https://gorest.co.in/";

		JSONObject reqData2 = new JSONObject();

		reqData2.put("name","John");
		reqData2.put("job","Teacher");

		System.out.println(reqData2.toJSONString());

		given()
		//	.header("content-type" , "application/json")
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData2.toJSONString())
		.when()
		.post("/public/v1/users/100/posts")
		.then()
		.log().status()
		.log().all();
	}

	@Test
	public void createPostComment() {
		baseURI = "https://gorest.co.in/";

		JSONObject reqData3 = new JSONObject();

		reqData3.put("name","John");
		reqData3.put("job","Teacher");

		System.out.println(reqData3.toJSONString());

		given()
		//	.header("content-type" , "application/json")
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData3.toJSONString())
		.when()
		.post("/public/v1/posts/100/comments")
		.then()
		.log().status()
		.log().all();
	}

	@Test
	public void createUserTODO() {
		baseURI = "https://gorest.co.in/";

		JSONObject reqData4 = new JSONObject();

		reqData4.put("name","John");
		reqData4.put("job","Teacher");

		System.out.println(reqData4.toJSONString());

		given()
		//	.header("content-type" , "application/json")
		.header("Connection", "Keep-alive")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(reqData4.toJSONString())
		.when()
		.post("/public/v1/users/100/todos")
		.then()
		.log().status()
		.log().all();
	}

	@Test
	public void testDeleteUser() {
		baseURI = "https://gorest.co.in/";
		when()
		.delete("/public/v1/users/100")
		.then()
		.log().status()
		.log().all();
	}

}