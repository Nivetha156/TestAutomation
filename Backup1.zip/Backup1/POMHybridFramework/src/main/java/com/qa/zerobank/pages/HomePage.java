package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase {
	
	@FindBy(id ="signin_button")
	WebElement signInButton;

	@FindBy(name="searchTerm")
	WebElement searchBox;

	@FindBy(linkText="Zero Bank")
	WebElement brandLinkZeroBank;
	
	@FindBy(css = "#online-banking")
	WebElement buttonMoreServices;

	@FindBy(className = "brand")
	WebElement brandLogo;
	
	@FindBy(xpath="//div[@class='top_offset']//a[1]")
	WebElement LinkAfterSearch;


	
	/*
	@FindBy(id="onlineBankingMenu")
	WebElement onlineBanking;

	@FindBy(id="feedback")
	WebElement feedBack;

	@FindBy(xpath="//a[contains(text(),'�')]")
	WebElement leftArrowButton;

	@FindBy(xpath="//a[contains(text(),'�')]")
	WebElement rightArrowButton;

	@FindBy(xpath="//img[contains(@src,'main_carousel_1.jpg')]")
	WebElement image;

	@FindBy(id="online-banking")
	WebElement onlineBankingButton;

	@FindBy(id="account_activity_link")
	WebElement accountActivity;

	@FindBy(id="transfer_funds_link")
	WebElement transferFund;

	@FindBy(id="money_map_link")
	WebElement moneyMap;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][1]")
	WebElement privacyLink1;

	@FindBy(xpath="//a[contains(@href,'/about/legal/#privacy')][2]")
	WebElement privacyLink2;
	
	*/
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertHomePageTitle() {
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	}

	public boolean validateBrandLogo() {
		return brandLogo.isDisplayed();
	}
	
	public LogInPage clickOnSignInButton() {
		signInButton.click();
		return new LogInPage();
	}
	
	public void searchBox() {
		searchBox.click();
		searchBox.sendKeys("online Banking");
		searchBox.sendKeys(Keys.ENTER);
		assertEquals(driver.getTitle(), "Zero - Search Tips", "Mismatch found");
		if(LinkAfterSearch.isDisplayed()) {
			LinkAfterSearch.click();
		}else {
			System.out.println("Link is not displayed");
		}
	}
	
	/*
	public SearchResultPage enterOnSearchBox(String searchData) {
		searchBox.click();
		searchBox.sendKeys(searchData);
		searchBox.sendKeys(Keys.ENTER);
		return new SearchResultPage();
	}
		//TEST
@Test
public void searchBoxTest() {
searchResultPage = homePage.enterOnSearchBox("Online Banking");
searchResultPage.assertSearchResultPageTitle();
searchResultPage.verifySearchResult();
}
	
		//SearchResultpage



public class SearchResultPage extends TestBase{



//object repository

@FindBy(xpath = "//h2[contains(text(),'Search Results:')]")
WebElement searchResults;

@FindBy(partialLinkText = "Online Banking")
WebElement OnlineBanking;

@FindBy(partialLinkText = "Pay Bills")
WebElement PayBills;

// @FindBy(Text = "searchTerm")
// WebElement searchBox;

// @FindBy(xpath="//div[@class='top_offset']//a[1]")
// WebElement NotFound;




//constructor

public SearchResultPage() {

PageFactory.initElements(driver, this);
}

//assert title

public void assertSearchResultPageTitle() {
assertEquals(driver.getTitle(), "Zero - Search Tips");
}

public OnlineBankingPage OnlineBankingPageLinkCLicked() {
OnlineBanking.click();
return new OnlineBankingPage();
}

public PayBillsPage PayBillsPageLinkClicked() {
PayBills.click();
return new PayBillsPage();
}

public void verifySearchResult() {
if(OnlineBanking.isDisplayed()) {
System.out.println("Result Found");
OnlineBankingPageLinkCLicked();
}else if(PayBills.isDisplayed()) {
System.out.println("Result Found");
PayBillsPageLinkClicked();
}else
System.out.println("Result not Found");

}

}
		
*/

	
	
}

