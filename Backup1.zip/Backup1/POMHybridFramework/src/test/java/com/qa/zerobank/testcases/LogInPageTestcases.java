package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;

public class LogInPageTestcases extends TestBase {
		
		HomePage homePage;
		LogInPage logInPage;
		AccountSummaryPage accountSummaryPage;
		TestUtil testUtil;
		

		public LogInPageTestcases() {
			super();
		}
		
		@BeforeMethod
		public void beforeMethod() {
			initialization();
			homePage = new HomePage();
			logInPage = new LogInPage();
			accountSummaryPage = new AccountSummaryPage();
			testUtil = new TestUtil();
		}
		
		@AfterMethod
		public void afterMethod() {
			TestUtil.takeScreenshotAtEndOfTest("LoginPage");
			driver.close();
			driver.quit();
		}
		
		@Test
		public void validateLogInpage() {
			logInPage = homePage.clickOnSignInButton();
			logInPage.assertLogInPageTitle();
		}
		
		@Test
		public void validateLogInFunctionality() {
			logInPage = homePage.clickOnSignInButton();
			accountSummaryPage = logInPage.logIn();
			accountSummaryPage.assertSummaryPageTitle();
					
		}
		

}
