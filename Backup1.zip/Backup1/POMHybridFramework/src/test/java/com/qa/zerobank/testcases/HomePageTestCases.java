package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;

public class HomePageTestCases extends TestBase {
	
	HomePage homePage;
	LogInPage logInPage;
	TestUtil testUtil;
	
	String sheetName = "Search";

	public HomePageTestCases() {
		super();
	}
	
	@BeforeMethod
	public void setUp() {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
		testUtil = new TestUtil();
	}
	
	@AfterMethod
	public void cleanUp() {
		TestUtil.takeScreenshotAtEndOfTest("HomePage");
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateHomePage() {
		homePage.assertHomePageTitle();
	}
	
	@Test
	public void validateLogo() {
		assertTrue(homePage.validateBrandLogo());
	}

	@Test
	public void signInButtonTest() {
		logInPage = homePage.clickOnSignInButton();
		logInPage.assertLogInPageTitle();
	}
	
	@Test
	public void validateSearchBox() {
		homePage.searchBox();
	}
	
	@Test
	public void executeExe() {
		testUtil.executeExeFile(System.getProperty("user.dir")+"\\src\\main\\resources\\com\\qa\\zerobank\\seleniumbrowserdrivers\\chromedriver.exe");
	}
	
	 @Test
	    public void dbConnectionTest() throws SQLException, ClassNotFoundException {

	        Connection testcon = testUtil.createDBConnection();
	        ResultSet results = testUtil.executeDBQuery(testcon, "select * from student");

	        //run through each row of result for a column
	        while(results.next()) {
	            String studentname = results.getString("Name");
	            System.out.println("Student name is " + studentname);
	        }

	        testUtil.closeConnection(testcon);

	    }
	
}
