package restassuredtestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class GetRequest {

	@Test
	void testGetUsersList() {
		
		System.out.println("----------List of Users---------");
		Response rsp = RestAssured.get("https://reqres.in/api/users?page=2");
		
		//to validate status code
		System.out.println(rsp.getStatusCode());
		Assert.assertEquals(rsp.getStatusCode(), 200);
		
		//to get response body
		System.out.println("The response body is - \n" + rsp.body().asString());
		System.out.println(rsp.getBody().asString());
		
		//to get response time
		System.out.println("The response time is - " + rsp.getTime());
	
		//to get specific header
		System.out.println("Content type is - " + rsp.header("content-type"));
		
		//to get all headers
		System.out.println("Response Headers are - " + rsp.headers());	
	}
		
	@Test
	void testGetSpecificUserDetails() {
		
		System.out.println("----------Single user---------");
		
		String userid ="2";
		Response rsp = RestAssured.get("https://reqres.in/api/users/" + userid);
		
		//to validate status code
		System.out.println(rsp.getStatusCode());
		Assert.assertEquals(rsp.getStatusCode(), 200);
		
		//to get response body
		System.out.println("The response body is - \n" + rsp.body().asString());
		System.out.println(rsp.getBody().asString());
		
		//to get response time
		System.out.println("The response time is - " + rsp.getTime());
	
		//to get specific header
		System.out.println("Content type is - " + rsp.header("content-type"));
		
		//to get all headers
		System.out.println("Response Headers are - " + rsp.headers());	
	}
}