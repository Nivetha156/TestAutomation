package com.qa.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.orangehrm.base.TestBase;

public class Candidate extends TestBase {
	
	
	@FindBy(id="addCandidate_firstName")
	WebElement firstName;

	@FindBy(id="addCandidate_lastName")
	WebElement lastName;

	@FindBy(id="addCandidate_email")
	WebElement email;
	
	@FindBy(id="btnSave")
	WebElement Save;
	
	@FindBy(id="btnAdd")
	WebElement Add;
	
	@FindBy(xpath="//div[@id='divLogo']/img[1]")
	WebElement Logo;
	
	@FindBy(xpath="//li[@class='ac_even ac_over']")
	WebElement List;
	
	@FindBy(id="menu_recruitment_viewCandidates")
	WebElement Candidates;
	
	@FindBy(id="candidateSearch_candidateName")
	WebElement candidateSearchName;	
	
	@FindBy(linkText ="nivetha  sekar")
	WebElement Nameofcand;	

	@FindBy(id ="btnSrch")
	WebElement search;	
	
	public Candidate() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM", "Mismatch found");
	}
	
	public void ClickAddBtn() {
		Add.click();
	}

	public void Adduser() {
		firstName.sendKeys(prop.getProperty("fname"));
		lastName.sendKeys(prop.getProperty("lname"));
		email.sendKeys(prop.getProperty("email"));
	}
	
	public void AdduseBtn() {
		Save.click();
	}
	
	public void VerfAdduser() {
		candidateSearchName.sendKeys(prop.getProperty("fname"));
		List.click();
		search.click();
	}
	
	public void clickCand() {
		Candidates.click();
	}

}
