package com.qa.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.orangehrm.base.TestBase;

public class HomePage extends TestBase  {

	@FindBy(xpath="//b[text()='Recruitment']")
	WebElement Recruitment;

	@FindBy(id="menu_recruitment_viewCandidates")
	WebElement Candidates;
	
	@FindBy(xpath="//div[@id='branding']//img")
	WebElement Logo;
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}

		public void assertHomePageTitle() {
			assertEquals(driver.getTitle(), "OrangeHRM", "Title Mismatch Found");
		}
		
		public boolean VerifyLogo() {
			return Logo.isDisplayed();
		}
		
		public void MovetoRecruitment() {			
			Actions action = new Actions(driver);
			action.moveToElement(Recruitment).perform();
		}
		
		public void movetoCandidates() {
			Actions action = new Actions(driver);
			action.moveToElement(Candidates).perform();
		}
		
		public Candidate NavigatetoCandidates() {
			Candidates.click();
			return new Candidate();
		}
}
