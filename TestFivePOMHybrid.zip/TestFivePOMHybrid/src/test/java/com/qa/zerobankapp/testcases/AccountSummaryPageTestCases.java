package com.qa.zerobankapp.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobankapp.base.TestBase;
import com.qa.zerobankapp.pages.AccountSummaryPage;
import com.qa.zerobankapp.pages.HomePage;
import com.qa.zerobankapp.pages.LogInPage;

public class AccountSummaryPageTestCases extends TestBase {

	HomePage homepage;
	LogInPage loginpage;
	AccountSummaryPage accountsummarypage;

	public AccountSummaryPageTestCases() {
		super();
	}

	@BeforeMethod
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		accountsummarypage = new AccountSummaryPage();
	}


	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateAccountSummaryPageTitle() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();
		accountsummarypage.signOut();
	}

	@Test
	public void signOutTest() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.signOut();
	}
}
