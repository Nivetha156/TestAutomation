package com.qa.zerobankapp.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobankapp.base.TestBase;
import com.qa.zerobankapp.pages.AccountSummaryPage;
import com.qa.zerobankapp.pages.HomePage;
import com.qa.zerobankapp.pages.LogInPage;


public class LogInPageTestCases extends TestBase {

	HomePage homepage;
	LogInPage loginpage;
	AccountSummaryPage accountsummarypage;

	public LogInPageTestCases() {
		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		accountsummarypage = new AccountSummaryPage();
	}

	@AfterMethod
	public void quit() {
		driver.close();
		driver.quit();
	}

	@Test
	public void validateLogInPageFunctionality() {
		loginpage = homepage.clickSigninButton();
	}

	@Test
	public void enterValidUserNameInvalidPasswordTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.enterValidUserNameInvalidPassword();
	}

	@Test
	public void enterInvalidUserNameValidPasswordTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.enterInvalidUserNameValidPassword();
	}
	
	@Test
	public void emptyCredentialsTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.emptyCredentials();
	}
	
	@Test
	public void enterInvalidUserNameInvalidPasswordTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.enterInvalidUserNameInvalidPassword();
	}

	@Test
	public void emptyUserNameTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.emptyUserName();
	}

	@Test
	public void navigateToAccountSummaryPageTest() {
		loginpage = homepage.clickSigninButton();
		accountsummarypage = loginpage.navigateToAccountSummaryPage();
		accountsummarypage.assertAccountSummaryPageTitle();
	}
}
