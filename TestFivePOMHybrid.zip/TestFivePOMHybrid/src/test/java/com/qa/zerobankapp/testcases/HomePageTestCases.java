package com.qa.zerobankapp.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobankapp.base.TestBase;
import com.qa.zerobankapp.pages.HomePage;
import com.qa.zerobankapp.pages.LogInPage;

public class HomePageTestCases extends TestBase {
	
	HomePage homepage;
	LogInPage loginpage;
	
	public HomePageTestCases() {
		super();
	}

	@BeforeMethod
	public void setup() {
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
	}
	
	@AfterMethod
	public void tearDown() {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void ValidateHomePage() {
		homepage.assertHomePageTitle();
	}

	@Test
	public void ValidateLogo() {
		homepage.assertHomePageTitle();
	}
	
	@Test
	public void signInButtonTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.assertLogInPageTitle();
		
	}
	
	
	
}
