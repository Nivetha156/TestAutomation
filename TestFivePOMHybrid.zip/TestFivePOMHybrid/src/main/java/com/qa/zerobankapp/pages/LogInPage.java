package com.qa.zerobankapp.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobankapp.base.TestBase;

public class LogInPage extends TestBase {
	
	@FindBy(id = "user_login")
	WebElement lusername;
	
	@FindBy(name = "user_password")
	WebElement lpassword;

	@FindBy(name = "submit")
	WebElement signinbutton;
	
	@FindBy(id = "details-button")
	WebElement detailsbutton;
	
	@FindBy(linkText = "Proceed to zero.webappsecurity.com (unsafe)")
	WebElement proceedtolink;
	
	public LogInPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLogInPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Log in");
	}
	
	public void enterValidUserNameInvalidPassword() {
		lusername.sendKeys("username");
		lpassword.sendKeys("pass2345");
		signinbutton.click();
		assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
		System.out.println("First Negative Test case is Pass");
	}
	
	public void enterInvalidUserNameValidPassword() {
		lusername.sendKeys("asdff");
		lpassword.sendKeys("password");
		signinbutton.click();
		assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
		System.out.println("Second Negative Test case is Pass");
	}
	
	public void emptyCredentials() {
		lusername.sendKeys("");
		lpassword.sendKeys("");
		signinbutton.click();
		assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
		System.out.println("Third Negative Test case is Pass");
	}
	
	public void enterInvalidUserNameInvalidPassword() {
		lusername.sendKeys("asdff");
		lpassword.sendKeys("pass2345");
		signinbutton.click();
		assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
		System.out.println("Fourth Negative Test case is Pass");
	}
	
	public void emptyUserName() {
		lusername.sendKeys("");
		lpassword.sendKeys("password");
		signinbutton.click();
		assertEquals(driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText(), "Login and/or password are wrong.");
		System.out.println("Fifth Negative Test case is Pass");
	}
	
	public AccountSummaryPage navigateToAccountSummaryPage() {
		
		//valid username and valid password
		lusername.sendKeys(prop.getProperty("username"));
		lpassword.sendKeys(prop.getProperty("password"));
		signinbutton.click();
		System.out.println("First Postive Testcase is Pass");	
		detailsbutton.click();
		proceedtolink.click();
		//title verify
		assertEquals(driver.getTitle(), "Zero - Account Summary");
		System.out.println("Second Postive Testcase is Pass");
		return new AccountSummaryPage();
	}	
	
}
