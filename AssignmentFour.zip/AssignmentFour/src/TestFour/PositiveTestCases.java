package TestFour;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PositiveTestCases {
	
	public WebDriver driver;

	@BeforeTest(alwaysRun = true)
	public void sepUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	}

	@BeforeMethod(alwaysRun = true)
	public void openURLandLogin() {
		driver.get("http://zero.webappsecurity.com/");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.cssSelector("[value='Sign in']")).click();
	}
	
	//Testcase1
	
	@Test(enabled = true, priority = 1, groups = {"SmokeTest"})
	public void TestCaseOne() {
		
		WebElement advancedButton = driver.findElement(By.id("details-button"));
		if(advancedButton.isDisplayed()) {
			advancedButton.click();
			WebElement proceedAnywayButton = driver.findElement(By.xpath("//*[@id='proceed-link']"));
			proceedAnywayButton.click();
		}
		
		driver.findElement(By.linkText("Pay Bills")).click();	
		
		WebDriverWait eWait = new WebDriverWait(driver, 5);
		driver.findElement(By.partialLinkText("Foreign Currency")).click();
		eWait.until(ExpectedConditions.textToBePresentInElement(driver.findElement(By.xpath("//h2[text()='Purchase foreign currency cash']")), "Purchase foreign currency cash"));
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.id("purchase_cash")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		System.out.println(alertText);

		assertEquals(alertText,"Please, ensure that you have filled all the required fields with valid values.","Test Failed");
		alert.accept();
		System.out.println("First Positive Test case is Pass");
	}
	
	//Testcase2
	
	@Test(priority = 2, groups = {"SmokeTest"})
	public void TestCaseTwo() {
		driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		WebElement From=driver.findElement(By.id("tf_fromAccountId"));
		Select sel1 = new Select (From);
		sel1.selectByValue("3");
		
		WebElement To=driver.findElement(By.id("tf_toAccountId"));
		Select sel2 = new Select (To);
		sel2.selectByVisibleText("Credit Card(Avail. balance = $ -265)");
		
		driver.findElement(By.name("amount")).sendKeys("100");
		driver.findElement(By.id("tf_description")).sendKeys("Deposit");
		
		driver.findElement(By.xpath("//button[@id='btn_submit']"));
		driver.findElement(By.xpath("//button[@id='btn_submit']"));
		//assertEquals(driver.findElement(By.xpath("//div[contains(text(),'You successfully submitted your transaction.')]")),"You successfully submitted your transaction.","Test Failed");
		System.out.println("Second Positive Test case is Pass");
	}
	
	@AfterMethod(alwaysRun = true)
	public void logout() {
		WebElement clickDropDown = driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]"));
		clickDropDown.click();
		WebElement clickLogout = driver.findElement(By.cssSelector("a#logout_link"));
		clickLogout.click();
	}


	@AfterTest(alwaysRun = true)
	public void cleanUp() {
		driver.close();
		driver.quit();
	}
}

