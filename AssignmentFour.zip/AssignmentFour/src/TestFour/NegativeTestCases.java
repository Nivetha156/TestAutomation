package TestFour;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class NegativeTestCases {
	public WebDriver driver ;

	@BeforeTest(alwaysRun = true)
	public void sepUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	}
		
	//Testcase1 (username -> valid & password -> invalid)
	@Test (priority = 1, groups = {"RegressionTest"})
	public void testcase1() {
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("pass2345");
		driver.findElement(By.cssSelector("[value='Sign in']")).click();
		String errormsg1 = driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText();
		Assert.assertEquals(errormsg1, "Login and/or password are wrong.");
		System.out.println("First Negative Test case is Pass");
	}
	
	//Testcase2 (username -> invalid & password -> valid)
	@Test (priority = 2, groups = {"RegressionTest"})
	public void testcase2() {
		driver.findElement(By.name("user_login")).sendKeys("asdff");
		driver.findElement(By.id("user_password")).sendKeys("password");
		driver.findElement(By.cssSelector("[value='Sign in']")).click();
		String errormsg2 = driver.findElement(By.xpath("//div[contains(text(),'Login and/or password are wrong.')]")).getText();
		Assert.assertEquals(errormsg2, "Login and/or password are wrong.");
		System.out.println("Second Negative Test case is Pass");
	}
	
	//Testcase3 (username -> empty & password -> empty)
	@Test(priority = 3, groups = {"RegressionTest"})
	public void testcase3() {	
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.xpath("//input[@id='btnLogin']")).click();
		String errormsg3 = driver.findElement(By.xpath("//span[@id='spanMessage']")).getText();
		Assert.assertEquals(errormsg3, "Username cannot be empty");
		System.out.println("Third Negative Test case is Pass");
	}
	
	//Testcase4 (username -> valid & password -> empty)
	@Test(priority = 4, groups = {"RegressionTest"})
	public void testcase4() {
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		driver.findElement(By.xpath("//input[@id='btnLogin']")).click();
		String errormsg4 = driver.findElement(By.xpath("//span[@id='spanMessage']")).getText();
		Assert.assertEquals(errormsg4, "Password cannot be empty");
		System.out.println("Fourth Negative Test case is Pass");
	}
	
	//Testcase5 (username -> invalid & password -> invalid)
	@Test(priority = 5, groups = {"RegressionTest"})
	public void testcase5() {
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/");
		driver.findElement(By.name("txtUsername")).sendKeys("admin455");
		driver.findElement(By.name("txtPassword")).sendKeys("admin455");
		driver.findElement(By.xpath("//input[@id='btnLogin']")).click();
		String errormsg5 = driver.findElement(By.xpath("//span[@id='spanMessage']")).getText();
		Assert.assertEquals(errormsg5, "Invalid credentials");
		System.out.println("Fifth Negative Test case is Pass");
	}

	@AfterTest(alwaysRun = true)
	public void cleanUp() {
		driver.close();
		driver.quit();
	}
}